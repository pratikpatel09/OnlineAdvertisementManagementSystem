package com.name.photo.birthday.cake.quotes.frame.editor.mask;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;

import androidx.core.view.ViewCompat;

import com.name.photo.birthday.cake.quotes.frame.editor.R;


public abstract class PorterImageView extends TouchImageView {
    private static final PorterDuffXfermode PORTER_DUFF_XFERMODE = new PorterDuffXfermode(Mode.DST_IN);
    private static final String TAG = PorterImageView.class.getSimpleName();
    private Bitmap drawableBitmap;
    private Canvas drawableCanvas;
    private Paint drawablePaint;
    private boolean invalidated = true;
    private Bitmap maskBitmap;
    private Canvas maskCanvas;
    private Paint maskPaint;
    private boolean square = false;

    /* access modifiers changed from: protected */
    public abstract void paintMaskCanvas(Canvas canvas, Paint paint, int i, int i2);

    public PorterImageView(Context context) {
        super(context);
        setup(context, null, 0);
    }

    public PorterImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setup(context, attrs, 0);
    }

    public PorterImageView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        setup(context, attrs, defStyle);
    }

    public void setSquare(boolean square2) {
        this.square = square2;
    }

    private void setup(Context context, AttributeSet attrs, int defStyle) {
        if (attrs != null) {
            TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.ShaderImageView, defStyle, 0);
            this.square = typedArray.getBoolean(R.styleable.ShaderImageView_siSquare, false);
            typedArray.recycle();
        }
        if (getScaleType() == ScaleType.FIT_CENTER) {
            setScaleType(ScaleType.CENTER_CROP);
        }
        this.maskPaint = new Paint(1);
        this.maskPaint.setColor(ViewCompat.MEASURED_STATE_MASK);

    }

    public void invalidate() {
        this.invalidated = true;
        super.invalidate();
    }


    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        createMaskCanvas(w, h, oldw, oldh);
    }

    private void createMaskCanvas(int width, int height, int oldw, int oldh) {
        boolean sizeChanged;
        boolean isValid = false;
        if (width == oldw && height == oldh) {
            sizeChanged = false;
        } else {
            sizeChanged = true;
        }
        if (width > 0 && height > 0) {
            isValid = true;
        }
        if (!isValid) {
            return;
        }
        if (this.maskCanvas == null || sizeChanged) {
            System.gc();
            this.maskCanvas = new Canvas();
            this.maskBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
            this.maskCanvas.setBitmap(this.maskBitmap);
            this.maskPaint.reset();
            paintMaskCanvas(this.maskCanvas, this.maskPaint, width, height);
            this.drawableCanvas = new Canvas();
            this.drawableBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
            this.drawableCanvas.setBitmap(this.drawableBitmap);
            this.drawablePaint = new Paint(1);
            this.invalidated = true;
        }
    }

    @Override
    public void onDraw(Canvas canvas) {
        if (!isInEditMode()) {
            int saveCount = canvas.saveLayer(0.0f, 0.0f, (float) getWidth(), (float) getHeight(), null, Canvas.ALL_SAVE_FLAG);
            try {
                if (this.invalidated) {
                    Drawable drawable = getDrawable();
                    if (drawable != null) {
                        this.invalidated = false;
                        Matrix imageMatrix = getImageMatrix();
                        if (imageMatrix == null) {
                            drawable.draw(this.drawableCanvas);
                        } else {
                            int drawableSaveCount = this.drawableCanvas.getSaveCount();
                            this.drawableCanvas.save();
                            this.drawableCanvas.concat(imageMatrix);
                            drawable.draw(this.drawableCanvas);
                            this.drawableCanvas.restoreToCount(drawableSaveCount);
                        }
                        this.drawablePaint.reset();
                        this.drawablePaint.setFilterBitmap(false);
                        this.drawablePaint.setXfermode(PORTER_DUFF_XFERMODE);
                        this.drawableCanvas.drawBitmap(this.maskBitmap, 0.0f, 0.0f, this.drawablePaint);
                    }
                }
                if (!this.invalidated) {
                    this.drawablePaint.setXfermode(null);
                    canvas.drawBitmap(this.drawableBitmap, 0.0f, 0.0f, this.drawablePaint);
                }
            } catch (Exception e) {
                Log.e(TAG, "Exception occured while drawing " + getId(), e);
            } finally {
                canvas.restoreToCount(saveCount);
            }
        } else {
            super.onDraw(canvas);
        }
    }

    @Override
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        if (this.square) {
            int dimen = Math.min(getMeasuredWidth(), getMeasuredHeight());
            setMeasuredDimension(dimen, dimen);
        }
    }
}
